import React from 'react';
declare const WebsiteDefaultUpiPaymentScreen: React.FC;
export default WebsiteDefaultUpiPaymentScreen;
//# sourceMappingURL=WebsiteDefaultUPIScreen.d.ts.map