import React from 'react';
declare const PaymentScreen: React.FC;
export default PaymentScreen;
//# sourceMappingURL=PaymentScreen.d.ts.map