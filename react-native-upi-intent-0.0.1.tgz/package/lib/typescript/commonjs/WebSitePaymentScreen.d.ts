import React from 'react';
declare const WebsitePaymentScreen: React.FC;
export default WebsitePaymentScreen;
//# sourceMappingURL=WebSitePaymentScreen.d.ts.map