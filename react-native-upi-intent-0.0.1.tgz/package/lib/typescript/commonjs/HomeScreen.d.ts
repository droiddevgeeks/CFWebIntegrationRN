import React from 'react';
import { StackNavigationProp } from '@react-navigation/stack';
export type RootStackParamList = {
    HomeScreen: undefined;
    AndroidJsPaymentScreen: undefined;
    WebsitePaymentScreen: undefined;
    WebsiteDefaultUPIScreen: undefined;
};
type HomeScreenNavigationProp = StackNavigationProp<RootStackParamList, 'HomeScreen'>;
interface HomeScreenProps {
    navigation: HomeScreenNavigationProp;
}
declare const HomeScreen: React.FC<HomeScreenProps>;
export default HomeScreen;
//# sourceMappingURL=HomeScreen.d.ts.map