export { default } from './index.android';
//# sourceMappingURL=index.d.ts.map