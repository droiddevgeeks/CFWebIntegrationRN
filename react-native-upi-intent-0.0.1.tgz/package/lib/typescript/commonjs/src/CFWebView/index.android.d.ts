import React from 'react';
export default class CFWebView extends React.Component {
    render(): React.JSX.Element;
}
//# sourceMappingURL=index.android.d.ts.map