import { WebView } from 'react-native-webview';
export default WebView;
//# sourceMappingURL=index.d.ts.map