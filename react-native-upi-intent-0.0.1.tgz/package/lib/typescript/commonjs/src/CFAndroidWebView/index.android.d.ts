import { ViewProps } from 'react-native';
interface CFWebViewProps extends ViewProps {
    paymentInfo?: object;
}
declare const CFWebView: import("react-native").HostComponent<CFWebViewProps>;
export default CFWebView;
//# sourceMappingURL=index.android.d.ts.map