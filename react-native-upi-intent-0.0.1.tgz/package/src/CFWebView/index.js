// import {WebView} from 'react-native-webview';
// export default WebView;
export { default } from './index.android';
